

document.getElementById("ratingForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const form = e.target;
  const formData = new FormData(form);
  const jsonData = {};

  const numericFields = ["Country Code", "Average Cost for two", "Price range", "Votes"];

  formData.forEach((value, key) => {
    if (numericFields.includes(key)) {
      jsonData[key] = Number(value);
    } else {
      jsonData[key] = value;
    }
  });

  fetch("/predict", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(jsonData)
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById("result").innerHTML =
        `Predicted Rating: <strong>${data.predicted_rating}</strong>`;
    })
    .catch(err => {
      document.getElementById("result").innerHTML =
        "Error: Unable to get prediction.";
      console.error(err);
    });
});

document.querySelector('button[type="reset"]').addEventListener("click", function () {
  document.getElementById("result").innerHTML = "";
});